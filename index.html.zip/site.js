/* VENDO website — shared behaviour for every page.
   Smooth scroll, starfield, header, scroll reveals, card inner reveals, tilt, parallax,
   page transitions, FAQ, tabs, download popup (desktop) / store menu (mobile).
   Page-specific parts (hero intro, Why VENDO story, counters…) switch on only when their elements exist. */
(function(){
  const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const root = document.documentElement;
  const $ = (s,c=document)=>c.querySelector(s), $$ = (s,c=document)=>[...c.querySelectorAll(s)];
  const BASE = (document.currentScript && document.currentScript.src || '').replace(/site\.js(\?.*)?$/, '');
  const clamp = (v,a=0,b=1) => Math.min(b, Math.max(a, v));
  const ease = t => 1 - Math.pow(1 - t, 3);
  const smooth = t => t * t * (3 - 2 * t);

  /* ---------- page links: open instantly; warm up the next page when a link is hovered or touched ---------- */
  const warmed = new Set();
  const warm = e => {
    const a = e.target.closest && e.target.closest('a[href]'); if (!a || a.target === '_blank') return;
    const url = new URL(a.href, location.href);
    if (url.origin !== location.origin || url.pathname === location.pathname || warmed.has(url.pathname)) return;
    warmed.add(url.pathname);
    /* fetch the next page and pre-load the images of its first screen, so its hero is ready the moment it opens */
    fetch(url.pathname, { credentials: 'same-origin' }).then(r => r.ok ? r.text() : '').then(html => {
      const top = html.slice(0, html.indexOf('</section>') + 1 || 60000);
      const srcs = [...top.matchAll(/<img[^>]+src="([^"]+)"/g)].map(m => new URL(m[1], url).href).slice(0, 14);
      srcs.forEach(src => { const i = new Image(); i.decoding = 'async'; i.src = src; });
    }).catch(() => {});
  };
  document.addEventListener('pointerover', warm, { passive: true });
  document.addEventListener('touchstart', warm, { passive: true });
  document.addEventListener('click', e => {
    const a = e.target.closest('a[href]'); if (!a || e.defaultPrevented || e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;
    if (a.target === '_blank' || a.hasAttribute('download')) return;
    const url = new URL(a.href, location.href);
    if (url.origin === location.origin && url.pathname === location.pathname && !url.hash) { e.preventDefault(); goTop(); }
  });

  /* ---------- smooth scroll ---------- */
  let lenis = null;
  if (!reduce && window.Lenis) {
    try { lenis = new Lenis({ duration: 1.15, easing: t => 1 - Math.pow(1 - t, 3.2), smoothWheel: true });
      const raf = t => { lenis.raf(t); requestAnimationFrame(raf); }; requestAnimationFrame(raf);
    } catch(e) { lenis = null; }
  }
  const scrollToY = (y, opts={}) => { if (lenis) lenis.scrollTo(y, Object.assign({ duration: 1.3, easing: t => 1 - Math.pow(1 - t, 4) }, opts)); else window.scrollTo({ top: y, behavior: reduce ? 'auto' : 'smooth' }); };

  /* ---------- header + mobile menu ---------- */
  const head = $('.site-head'), burger = $('#burger'), mnav = $('#mnav');
  function closeNav(){ if (!mnav) return; mnav.classList.remove('open'); root.classList.remove('menu-open'); burger && burger.setAttribute('aria-expanded','false'); if (lenis) lenis.start(); }
  function openNav(){ mnav.classList.add('open'); root.classList.add('menu-open'); burger.setAttribute('aria-expanded','true'); if (lenis) lenis.stop(); }
  if (burger && mnav) {
    burger.addEventListener('click', () => mnav.classList.contains('open') ? closeNav() : openNav());
    $$('[data-close-nav]', mnav).forEach(b => b.addEventListener('click', closeNav));
  }

  /* ---------- starfield ---------- */
  const cv = $('#stars');
  if (cv) {
    const cx = cv.getContext('2d'); let stars = [], W = 0, H = 0; const dpr = Math.min(devicePixelRatio || 1, 2);
    const sizeStars = () => { W = innerWidth; H = innerHeight; cv.width = W * dpr; cv.height = H * dpr; cx.setTransform(dpr,0,0,dpr,0,0);
      const n = Math.round(W * H / 9000); stars = Array.from({length:n}, () => ({ x: Math.random()*W, y: Math.random()*H, r: Math.random()*1.1 + .2, a: Math.random()*.5 + .15, s: Math.random()*.02 + .004, p: Math.random()*6.28, v: Math.random()*.08 + .02, g: Math.random() < .18 })); };
    const drawStars = t => {
      cx.clearRect(0,0,W,H);
      const sy = (window.scrollY * .06) % H;
      for (const s of stars){
        const tw = reduce ? s.a : s.a * (.55 + .45 * Math.sin(t * s.s + s.p));
        let y = s.y - sy * s.v * 10; y = ((y % H) + H) % H;
        cx.globalAlpha = tw; cx.fillStyle = s.g ? '#8affb9' : '#ffffff';
        cx.beginPath(); cx.arc(s.x, y, s.r, 0, 6.283); cx.fill();
      }
      cx.globalAlpha = 1;
      if (!reduce) requestAnimationFrame(drawStars);
    };
    sizeStars(); addEventListener('resize', sizeStars); requestAnimationFrame(drawStars);
  }

  /* ---------- reveal on scroll ---------- */
  // card → inner pieces that rise one after another once the card is in view
  const GROUPS = [
    ['.step', '.k,.t,.dot,.ico,h3,.s'], ['.ex-card', '.ic,.n,h3,p'], ['.side', '.chip,h3,li,.btn'],
    ['.rel-l', '.up,.marq,.big,.cap'], ['.ask', 'b,p,.btn'], ['.cat', '.ci,.tx b,.tx span'],
    ['.fbox', '.news b,.news form,.fr nav,.fr .row>div,.fr .row>.btn'],
    ['.rel-r', 'img|img'], ['.map', 'img|fade,.pulse|fade'],
    ['[data-inner]', '[data-i]'], ['[data-inner-img]', '[data-i]|img']
  ];
  let io = null;
  function setupGroups(){
    GROUPS.forEach(([cardSel, inner]) => $$(cardSel).forEach(card => {
      const g = card.matches('[data-r]') ? card : card.closest('[data-r]'); if (!g) return;
      g.setAttribute('data-rg', '');
      const base = parseFloat(getComputedStyle(g).getPropertyValue('--d')) || 0;
      inner.split(',').forEach(part => { const [sel, kind] = part.split('|'); $$(sel, card).forEach(el => el.setAttribute('data-ri', kind || el.getAttribute('data-i') || '')); });
      $$('[data-ri]', card).forEach((el, k) => el.style.setProperty('--rid', (base + .3 + k * .09).toFixed(2) + 's'));
    }));
  }
  const watchIO = ('IntersectionObserver' in window) ? new IntersectionObserver(es => es.forEach(e => { if (e.isIntersecting){ e.target.classList.add('in'); watchIO.unobserve(e.target);} }), { threshold: 0, rootMargin: '0px 0px 4% 0px' }) : null;
  if (!reduce && 'IntersectionObserver' in window) {
    root.classList.add('js-anim');
    io = new IntersectionObserver(es => es.forEach(e => { if (e.isIntersecting) { const el = e.target; el.classList.add('in'); io.unobserve(el);
        if (el.hasAttribute('data-rg')) setTimeout(() => $$('[data-ri]', el).forEach(x => { x.removeAttribute('data-ri'); x.style.removeProperty('--rid'); }), 2800); } }), { threshold: 0, rootMargin: '0px 0px 6% 0px' });
    $$('[data-r]').forEach(el => io.observe(el));
    setupGroups();
    $$('[data-watch]').forEach(el => watchIO.observe(el));
  } else $$('[data-watch]').forEach(el => el.classList.add('in'));

  /* ---------- hero intro + pointer parallax ---------- */
  const hero = $('.hero-intro');
  const startHero = () => { if (hero) requestAnimationFrame(() => hero.classList.add('ready')); };
  startHero(); if (reduce && hero) hero.classList.add('ready');
  const items = hero ? $$('.hv-item[data-depth]', hero) : [];
  let mx = 0, my = 0, tx = 0, ty = 0;
  if (hero && !reduce && matchMedia('(pointer:fine)').matches) {
    hero.addEventListener('pointermove', e => { const r = hero.getBoundingClientRect(); mx = (e.clientX - r.left) / r.width - .5; my = (e.clientY - r.top) / r.height - .5; });
    hero.addEventListener('pointerleave', () => { mx = 0; my = 0; });
  }

  /* ---------- Why VENDO: word split ---------- */
  const whyText = $('#whyText'), words = [];
  if (whyText && !reduce) {
    const txt = whyText.textContent.trim().split(/\s+/);
    whyText.textContent = '';
    txt.forEach((w,i) => { const s = document.createElement('span'); s.className = 'w'; s.textContent = w; whyText.appendChild(s); words.push(s); if (i < txt.length - 1) whyText.appendChild(document.createTextNode(' ')); });
    root.classList.add('js-why');
  }
  const why = $('#why'), globe = $('#globe'), slot = $('#globeSlot'), pin = $('.why-pin');

  /* ---------- tilt ---------- */
  if (!reduce && matchMedia('(pointer:fine)').matches) {
    $$('[data-tilt]').forEach(el => {
      const k = +el.dataset.tilt || 1;
      el.addEventListener('pointermove', e => { const r = el.getBoundingClientRect(); const x = (e.clientX - r.left) / r.width, y = (e.clientY - r.top) / r.height;
        el.style.transform = `perspective(900px) rotateX(${(.5 - y) * 5 * k}deg) rotateY(${(x - .5) * 6 * k}deg) translateY(-4px)`;
        el.style.setProperty('--mx', x*100 + '%'); el.style.setProperty('--my', y*100 + '%'); });
      el.addEventListener('pointerleave', () => { el.style.transform = ''; });
    });
  }

  /* ---------- background image loading: once the page has loaded, fetch and decode the remaining images in page order ---------- */
  const warmImages = () => {
    const rest = $$('img[loading="lazy"]');
    let i = 0;
    const next = () => {
      const batch = rest.slice(i, i + 4); i += 4;
      if (!batch.length) return;
      Promise.all(batch.map(img => { img.loading = 'eager'; return (img.decode ? img.decode() : Promise.resolve()).catch(() => {}); }))
        .then(() => (window.requestIdleCallback ? requestIdleCallback(next, { timeout: 300 }) : setTimeout(next, 60)));
    };
    next();
  };
  if (document.readyState === 'complete') setTimeout(warmImages, 200); else addEventListener('load', () => setTimeout(warmImages, 200), { once: true });

  /* ---------- pause looping animations in sections that are off screen (keeps scrolling smooth) ---------- */
  if ('IntersectionObserver' in window) {
    const offIO = new IntersectionObserver(es => es.forEach(e => e.target.classList.toggle('anim-off', !e.isIntersecting)), { rootMargin: '150px 0px' });
    $$('main > section, main > div, footer.foot').forEach(s => offIO.observe(s));
  }

  /* ---------- how it works: held on screen while the line runs step 1 → 2 → 3, then lets go ---------- */
  const how = $('#how'), howPin = how && $('.how-pin', how), hSteps = how ? $$('.step', how) : [], hFill = how && $('.track-fill', how), hTrack = how && $('.track', how);
  let hLive = false, hfc = 0, hStops = [], hPad = 0, hRun = 1;
  const howLayout = () => {
    if (!how || !howPin || !hFill) return;
    const want = !reduce && getComputedStyle(hTrack).display !== 'none' && innerHeight >= 560;
    if (want !== hLive) { hLive = want; how.classList.toggle('how-live', want); if (!want) { hSteps.forEach(s => s.classList.remove('on')); } }
    if (!hLive) return;
    const sr = $('.steps', how).getBoundingClientRect();
    hStops = hSteps.map(s => { const d = $('.dot', s).getBoundingClientRect(); return (d.left + d.width / 2 - sr.left) / sr.width; });
    const hb = head ? head.getBoundingClientRect().bottom + 8 : 80, h = howPin.offsetHeight, avail = innerHeight - hb;
    how.style.setProperty('--hp-top', Math.round(h <= avail ? hb + (avail - h) / 2 : Math.max(innerHeight - h, hb - 10)) + 'px');
    const cs = getComputedStyle(how); hPad = parseFloat(cs.paddingTop) || 0;
    hRun = Math.max(1, how.clientHeight - hPad - (parseFloat(cs.paddingBottom) || 0) - h);
  };
  howLayout(); addEventListener('resize', howLayout); addEventListener('load', howLayout, { once: true });
  /* progress → line position: travel to a dot, rest there a moment, travel to the next */
  const howTarget = p => {
    if (!hStops.length) return 0;
    const seg = [[0, .2, 0, hStops[0]], [.3, .58, hStops[0], hStops[1]], [.66, .92, hStops[1], hStops[2]]];
    let v = 0;
    for (const [a, b, f, t] of seg) { if (p >= b) v = t; else if (p > a) { v = f + (t - f) * smooth((p - a) / (b - a)); break; } else break; }
    return v;
  };

  /* ---------- frame loop: header, hero parallax, why story, scroll parallax ---------- */
  const par = $$('[data-speed]');
  let gb = 0, lastY = -1, lastW = 0, busy = 2;
  function frame(){
    const y = window.scrollY, vh = innerHeight;
    /* skip all DOM work while nothing moves (no scroll, no pointer easing, no globe easing) */
    if (y === lastY && innerWidth === lastW && busy <= 0 && Math.abs(mx - tx) < .001 && Math.abs(my - ty) < .001) { requestAnimationFrame(frame); return; }
    if (y === lastY && innerWidth === lastW) busy--; else busy = 2;
    lastY = y; lastW = innerWidth;
    head && head.classList.toggle('scrolled', y > 24);
    if (items.length) {
      tx += (mx - tx) * .07; ty += (my - ty) * .07;
      const hr = hero.getBoundingClientRect();
      if (hr.bottom > 0) items.forEach(it => { const d = +it.dataset.depth || 1; const p = it.firstElementChild;
        p.style.transform = `translate3d(${tx * d * 26}px, ${ty * d * 18 + (-hr.top) * .08 * d}px, 0)`; });
    }
    if (why && !reduce) {
      const r = why.getBoundingClientRect(); const small = innerWidth <= 700;
      /* desktop: pinned story (words, then the globe lifts off); phones: a normal section whose words light up as it scrolls in */
      /* desktop: progress runs while the block is held on screen (from when it sticks until it lets go) */
      const pinTop = parseFloat(getComputedStyle(pin).top) || 0, runway = Math.max(1, r.height - pin.offsetHeight);
      const p = small ? clamp((vh * .9 - r.top) / (vh * .75)) : clamp((pinTop - r.top) / runway);
      const pa = small ? p : clamp(p / .45), n = words.length;
      for (let i = 0; i < n; i++) { const wp = clamp((pa * (n + 6) - i) / 6), w = words[i], o = (.14 + .86 * wp).toFixed(2);
        if (w._o !== o) { w._o = o; w.style.opacity = o; } }
      /* after the words: the globe turns, grows and rises, then the section lets go and the next one comes in */
      const sr = slot.getBoundingClientRect();
      const target = small ? smooth(clamp((vh * .8 - sr.top) / (vh * .7))) : smooth(clamp((p - .4) / .6));
      gb += (target - gb) * .075; if (Math.abs(target - gb) < .0005) gb = target; else busy = 2;
      if (small) {
        globe.style.setProperty('--gy', (-28 * gb).toFixed(1) + 'px');
        globe.style.setProperty('--gs', (1 + .22 * gb).toFixed(4));
        globe.style.setProperty('--gr', (gb * 70).toFixed(2) + 'deg');
      } else {
        /* where the globe's centre sits while the block is held, measured from the layout so it does not follow the scroll */
        const held = pinTop + (sr.top - pin.getBoundingClientRect().top) + sr.height / 2;
        const rise = Math.max(0, held - vh * .4);
        globe.style.setProperty('--gy', (-rise * gb).toFixed(1) + 'px');
        globe.style.setProperty('--gs', (1 + .9 * gb).toFixed(4));
        globe.style.setProperty('--gr', (gb * 110).toFixed(2) + 'deg');
        pin.style.setProperty('--wf', (1 - smooth(clamp((gb - .08) / .5))).toFixed(3));
      }
      globe.style.setProperty('--gh', (.35 + .45 * gb).toFixed(3));
    }
    if (hLive) {
      const hr = how.getBoundingClientRect(), pinTop = parseFloat(how.style.getPropertyValue('--hp-top')) || 0;
      if (hr.bottom > -50 && hr.top < vh + 50) {
        const t = howTarget(clamp((pinTop - (hr.top + hPad)) / hRun));
        hfc += (t - hfc) * .09; if (Math.abs(t - hfc) < .0005) hfc = t; else busy = 2;
        hFill.style.setProperty('--hf', hfc.toFixed(4));
        hSteps.forEach((s, i) => { const on = hfc >= hStops[i] - .004; if (s._on !== on) { s._on = on; s.classList.toggle('on', on); } });
      }
    }
    par.forEach(el => { const r = el.getBoundingClientRect(); if (r.bottom < -200 || r.top > vh + 200) return; const c = (r.top + r.height/2 - vh/2); el.style.transform = `translate3d(0, ${c * (+el.dataset.speed)}px, 0)` + (el.tagName === 'IMG' && el.closest('.map') ? ' scale(1.06)' : ''); });
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);

  /* ---------- counters ---------- */
  const counters = $$('[data-count]'); let cio = null;
  if (counters.length && !reduce && 'IntersectionObserver' in window) {
    counters.forEach(c => c.textContent = '0');
    cio = new IntersectionObserver(es => es.forEach(e => { if (!e.isIntersecting) return; const c = e.target; cio.unobserve(c); const to = +c.dataset.count, t0 = performance.now();
      const step = t => { const k = clamp((t - t0) / 1800); c.textContent = Math.round(to * ease(k)); if (k < 1) requestAnimationFrame(step); }; requestAnimationFrame(step); }), { threshold: .6 });
    counters.forEach(c => cio.observe(c));
  }

  /* ---------- avatar marquee ---------- */
  $$('[data-marq]').forEach(m => { const av = [1,2,3,4,5,1,2,3,4,5];
    m.innerHTML = av.concat(av).map(i => `<span class="av"><img src="${BASE}assets/avatar${i}.webp" alt=""></span>`).join(''); });

  /* ---------- FAQ accordion ---------- */
  $$('.acc').forEach(acc => {
    if (root.classList.contains('js-anim')) { const io2 = new IntersectionObserver(es => es.forEach(e => { if (e.isIntersecting){ e.target.classList.add('in'); io2.unobserve(e.target);} }), { threshold: 0 }); $$('.qa', acc).forEach(el => io2.observe(el)); }
    acc.addEventListener('click', e => { const b = e.target.closest('.qa>button'); if (!b) return; const qa = b.parentElement; const open = !qa.classList.contains('open');
      $$('.qa', acc).forEach(x => { x.classList.remove('open'); x.firstElementChild.setAttribute('aria-expanded','false'); });
      if (open) { qa.classList.add('open'); b.setAttribute('aria-expanded','true'); } });
  });

  /* ---------- tabs (contact form, legal user/provider) ---------- */
  $$('[data-tabs]').forEach(box => {
    const btns = $$('[data-tab]', box), panels = $$('[data-panel]', box.closest('[data-tabs-scope]') || document);
    const ind = $('.tab-ind', box);
    const place = b => { if (!ind || !b) return; ind.style.width = b.offsetWidth + 'px'; ind.style.transform = `translateX(${b.offsetLeft - 4}px)`; };
    function show(key, push){
      const b = btns.find(x => x.dataset.tab === key) || btns[0]; key = b.dataset.tab;
      btns.forEach(x => { const on = x === b; x.setAttribute('aria-selected', on); x.tabIndex = on ? 0 : -1; });
      place(b);
      panels.forEach(p => { const on = p.dataset.panel === key; if (on) { p.hidden = false; p.classList.remove('leave'); requestAnimationFrame(() => p.classList.add('show')); } else { p.classList.remove('show'); p.hidden = true; } });
      if (push && box.hasAttribute('data-hash')) history.replaceState(null, '', '#' + key);
      box.dispatchEvent(new CustomEvent('tabchange', { detail: key }));
    }
    btns.forEach(b => b.addEventListener('click', () => show(b.dataset.tab, true)));
    box.addEventListener('keydown', e => { if (!['ArrowLeft','ArrowRight'].includes(e.key)) return; const i = btns.findIndex(x => x.getAttribute('aria-selected') === 'true'); const n = btns[(i + (e.key === 'ArrowRight' ? 1 : -1) + btns.length) % btns.length]; n.focus(); show(n.dataset.tab, true); });
    const fromHash = box.hasAttribute('data-hash') && location.hash.slice(1);
    show(fromHash && btns.some(b => b.dataset.tab === fromHash) ? fromHash : (btns.find(b => b.getAttribute('aria-selected') === 'true') || btns[0]).dataset.tab, false);
    addEventListener('resize', () => place(btns.find(x => x.getAttribute('aria-selected') === 'true')));
    if (box.hasAttribute('data-hash')) addEventListener('hashchange', () => { const h = location.hash.slice(1); if (!btns.some(b => b.dataset.tab === h)) return; show(h, false);
      const sc = box.closest('[data-tabs-scope]') || box; scrollToY(sc.getBoundingClientRect().top + window.scrollY - 110); });
    if (document.fonts) document.fonts.ready.then(() => place(btns.find(x => x.getAttribute('aria-selected') === 'true')));
  });

  /* ---------- contact forms: light front-end check + thank-you note (sending is wired up by the developer) ---------- */
  $$('.ct-form').forEach(f => {
    f.addEventListener('input', e => e.target.classList.remove('bad'));
    f.addEventListener('submit', e => { e.preventDefault();
      $$('.bad', f).forEach(x => x.classList.remove('bad'));
      const bad = $$('[required]', f).filter(i => !i.value.trim() || (i.type === 'email' && !/^\S+@\S+\.\S+$/.test(i.value.trim())));
      if (bad.length) { bad.forEach(i => i.classList.add('bad')); bad[0].focus(); return; }
      let ok = $('.ok', f); if (!ok) { ok = document.createElement('p'); ok.className = 'ok'; ok.setAttribute('role', 'status'); f.appendChild(ok); }
      ok.textContent = f.dataset.ok || 'Thank you!'; requestAnimationFrame(() => ok.classList.add('show')); f.reset();
    });
  });

  /* ---------- carousel dots (mobile category slider) ---------- */
  $$('.dots[data-for]').forEach(d => { const box = document.getElementById(d.dataset.for); if (!box) return; const dots = $$('i', d);
    const upd = () => { const kids = [...box.children]; const c = box.scrollLeft + box.clientWidth / 2; let best = 0, bd = 1e9;
      kids.forEach((k,i) => { const m = k.offsetLeft + k.offsetWidth / 2 - box.offsetLeft; const dd = Math.abs(m - c); if (dd < bd) { bd = dd; best = i; } });
      dots.forEach((x,i) => x.classList.toggle('on', i === best)); };
    box.addEventListener('scroll', () => requestAnimationFrame(upd), { passive:true }); });

  /* ---------- steps line ---------- */
  const st = $('.steps'); const top0 = $('.step .top'); if (st && top0) { const setTop = () => st.style.setProperty('--top-h', top0.offsetHeight + 'px'); setTop(); addEventListener('resize', setTop); }

  /* ---------- newsletter ---------- */
  $$('form.nl').forEach(f => f.addEventListener('submit', e => { e.preventDefault(); const i = $('input', f); const b = $('button', f);
    if (!/^\S+@\S+\.\S+$/.test(i.value)) { i.focus(); i.placeholder = f.dataset.bad || 'Enter a valid email'; i.value=''; return; }
    b.textContent = f.dataset.done || 'Subscribed'; i.value = ''; i.placeholder = f.dataset.ok || 'Thanks! See you soon.'; }));

  /* ---------- Download App: QR popup (desktop) / store menu (mobile) ---------- */
  const dl = $('#dl'), menu = $('#menu');
  const STORE = {
    android: { url:'https://play.google.com/store/apps/details?id=com.vendo', N:33, rows:'feb87d3f8,828aa3208,ba6e03ae8,ba8941ae8,ba6492ae8,8243fca08,feaaaabf8,00a1e3000,b713f5258,4d64b9b78,f6846bbd8,c4f988150,d34bd3dc0,ac3e14950,bf8834ae0,f8d71f620,f36c8eee0,619d43ac8,b30fc83b0,4521e3688,57f39c970,b031f9a48,22112fb38,4df7295c8,de8452f90,00e3b58d0,fef2f5a80,8295ef8f0,ba12fffa8,baf482148,badfeb320,824662d88,feb0654a0' },
    apple: { url:'https://apps.apple.com/app/id1640955198', N:29, rows:'fe6273f8,8239ca08,bab38ae8,ba85d2e8,ba9e3ae8,82e1aa08,feaaabf8,00a39800,be05d3e0,011e1e88,3249ab00,f51136d0,7778c160,0d2c1f88,9b3f24e0,d51d3890,067bf160,e5b073a8,83714ca0,b56b8c90,ebf1cfb8,00f668f8,fe6f3ae0,82dc9888,baebcfa0,badc2178,bab99bf0,827d2dd0,fec9f4a0' }
  };
  const ICO = { play:'<svg viewBox="0 0 512 512"><path d="M325.3 234.3L104.6 13l280.8 161.2-60.1 60.1zM47 0C34 6.8 25.3 19.2 25.3 35.3v441.3c0 16.1 8.7 28.5 21.7 35.3l256.6-256L47 0zm425.2 225.6l-58.9-34.1-65.7 64.5 65.7 64.5 60.1-34.1c18-14.3 18-46.5-1.2-60.8zM104.6 499l280.8-161.2-60.1-60.1L104.6 499z"/></svg>',
    apple:'<svg viewBox="0 0 384 512"><path d="M318.7 268.7c-.2-36.7 16.4-64.4 50-84.8-18.8-26.9-47.2-41.7-84.7-44.6-35.5-2.8-74.3 20.7-88.5 20.7-15 0-49.4-19.7-76.4-19.7C63.3 141.2 4 184.8 4 273.5q0 39.3 14.4 81.2c12.8 36.7 59 126.7 107.2 125.2 25.2-.6 43-17.9 75.8-17.9 31.8 0 48.3 17.9 76.4 17.9 48.6-.7 90.4-82.5 102.6-119.3-65.2-30.7-61.7-90-61.7-91.9zm-56.6-164.2c27.3-32.4 24.8-61.9 24-72.5-24.1 1.4-52 16.4-67.9 34.9-17.5 19.8-27.8 44.3-25.6 71.9 26.1 2 49.9-11.4 69.5-34.3z"/></svg>' };
  let lastFocus = null;
  function qrSvg(k){ const q = STORE[k], N = q.N, rows = q.rows.split(','); const bit = (r,c) => (parseInt(rows[r][c>>2],16) >> (3-(c&3))) & 1;
    const eye = (r,c) => (r<7&&c<7)||(r<7&&c>=N-7)||(r>=N-7&&c<7); let d = '';
    for (let r=0;r<N;r++){ let c=0; while(c<N){ if(bit(r,c)&&!eye(r,c)){ const s=c; while(c<N&&bit(r,c)&&!eye(r,c)) c++; d+=`M${s} ${r}h${c-s}v1h${s-c}z`; } else c++; } }
    let e=''; for (const [y,x] of [[0,0],[0,N-7],[N-7,0]]) e += `<rect x="${x+.5}" y="${y+.5}" width="6" height="6" rx="1.2" fill="none" stroke="#021114" stroke-width="1"/><rect x="${x+2}" y="${y+2}" width="3" height="3" rx=".4" fill="#021114"/>`;
    return `<svg viewBox="0 0 ${N} ${N}" shape-rendering="crispEdges"><path d="${d}" fill="#021114"/><g shape-rendering="geometricPrecision">${e}</g></svg>`; }
  function closeDl(){ if (!dl || dl.hidden) return; dl.classList.remove('show'); setTimeout(() => { dl.hidden = true; }, 320); if (lenis) lenis.start(); if (lastFocus) lastFocus.focus(); }
  function closeMenu(){ if (!menu || menu.hidden) return; menu.classList.remove('show'); setTimeout(() => { menu.hidden = true; }, 250); }
  if (dl && menu) {
    const qr = $('#qr'), store = $('#store');
    const setPlat = (k, anim) => { $$('.tabs button', dl).forEach(b => b.setAttribute('aria-selected', b.dataset.p === k));
      const apply = () => { qr.innerHTML = qrSvg(k); store.href = STORE[k].url; $('#storeCap').textContent = dl.dataset['cap' + (k==='android'?'A':'I')]; $('#storeName').textContent = k==='android' ? 'Google Play' : 'App Store'; $('#storeIcon').innerHTML = ICO[k==='android'?'play':'apple']; };
      if (anim && !reduce) { qr.classList.add('flip'); setTimeout(() => { apply(); qr.classList.remove('flip'); }, 220); } else apply(); };
    $$('.tabs button', dl).forEach(b => b.addEventListener('click', () => setPlat(b.dataset.p, true)));
    const openDl = btn => { lastFocus = btn; setPlat('android'); dl.hidden = false; requestAnimationFrame(() => dl.classList.add('show')); if (lenis) lenis.stop(); setTimeout(() => $('.dl-x', dl).focus(), 50); };
    $$('[data-close]', dl).forEach(b => b.addEventListener('click', closeDl));
    $$('#menu [data-ico]').forEach(el => el.innerHTML = ICO[el.dataset.ico]);
    const openMenu = btn => { const r = btn.getBoundingClientRect(); menu.hidden = false; const w = 232;
      let left = Math.min(Math.max(12, r.left), innerWidth - w - 12); let top = r.bottom + 8; if (top + 150 > innerHeight) top = r.top - 150 - 8;
      menu.style.left = left + 'px'; menu.style.top = top + 'px'; requestAnimationFrame(() => menu.classList.add('show')); };
    const isMobile = () => matchMedia('(max-width: 700px)').matches;
    $$('[data-dl]').forEach(b => b.addEventListener('click', e => { e.preventDefault(); e.stopPropagation(); if (isMobile()) { menu.hidden ? openMenu(b) : closeMenu(); } else openDl(b); }));
    document.addEventListener('click', e => { if (!menu.hidden && !menu.contains(e.target)) closeMenu(); });
    addEventListener('scroll', () => { if (!menu.hidden) closeMenu(); }, { passive:true });
  }
  document.addEventListener('keydown', e => { if (e.key === 'Escape') { closeDl(); closeMenu(); closeNav(); } });

  /* ---------- logo / current-page link: glide back to the top and replay the page ---------- */
  function resetAll(){
    gb = 0; hfc = 0; pin && pin.style.removeProperty('--wf');
    if (!io) return;
    root.classList.add('no-tr');
    $$('[data-r],[data-watch]').forEach(el => el.classList.remove('in'));
    setupGroups();
    words.forEach(w => { w._o = null; w.style.opacity = '.14'; w.style.removeProperty('filter'); }); busy = 2;
    hero && hero.classList.remove('ready');
    void document.body.offsetHeight;
    root.classList.remove('no-tr');
    startHero();
    $$('[data-r]').forEach(el => io.observe(el));
    $$('[data-watch]').forEach(el => watchIO.observe(el));
    if (cio) counters.forEach(c => { c.textContent = '0'; cio.observe(c); });
  }
  function goTop(){
    closeNav(); closeDl(); closeMenu();
    let done = false; const fin = () => { if (done) return; done = true; resetAll(); };
    if (window.scrollY <= 2) { fin(); return; }
    if (lenis) lenis.scrollTo(0, { duration: 1.6, easing: t => 1 - Math.pow(1 - t, 4), force: true, onComplete: fin });
    else window.scrollTo({ top: 0, behavior: reduce ? 'auto' : 'smooth' });
    const wait = () => { if (done) return; if (window.scrollY <= 2) fin(); else requestAnimationFrame(wait); }; requestAnimationFrame(wait);
  }
  $$('[data-top]').forEach(b => b.addEventListener('click', e => { e.preventDefault(); goTop(); }));

  /* ---------- legal pages: contents list (sticky on desktop, "On this page" picker on mobile) + scroll spy ---------- */
  $$('.lg-grid').forEach(g => {
    const links = $$('.lg-toc a', g), secs = links.map(a => document.getElementById(a.getAttribute('href').slice(1)));
    const pick = $('.lg-pick', g), side = $('.lg-side', g);
    const shut = () => { side.classList.remove('open'); pick && pick.setAttribute('aria-expanded', 'false'); };
    pick && pick.addEventListener('click', () => { const o = side.classList.toggle('open'); pick.setAttribute('aria-expanded', o); });
    links.forEach(a => a.addEventListener('click', shut));
    const spy = () => { if (g.hidden) return; let cur = 0; secs.forEach((sec, i) => { if (sec && sec.getBoundingClientRect().top < 170) cur = i; }); links.forEach((a, i) => a.classList.toggle('on', i === cur)); };
    addEventListener('scroll', () => requestAnimationFrame(spy), { passive:true }); spy();
  });

  /* ---------- in-page anchors (legal contents) ---------- */
  $$('a[href^="#"][data-jump]').forEach(a => a.addEventListener('click', e => { const t = document.getElementById(a.getAttribute('href').slice(1)); if (!t) return; e.preventDefault();
    scrollToY(t.getBoundingClientRect().top + window.scrollY - 110); }));

  window.VENDO = { lenis, scrollToY, goTop, BASE };
})();
